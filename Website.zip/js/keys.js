// keys.js
// Contains keys to run this demo
// The keys should be kept secret and separate from the code
// Enter your keys below to take the first in running this step 
// VROOOOM VROOM

function getKeys () {
	return {
		CLARIFAI_CLIENT_ID: "OB_xdxt6E1kc6-JSrLLa_m2p44PF0caUaQS44KbO",
		CLARIFAI_CLIENT_SECRET: "P7YEWy4yC53S6jJf4iZ3mfLKYOO-9s2VgXW8jNyd"
	}
}